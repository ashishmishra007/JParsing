package com.example.jsonparsing;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;

import com.Ashish.Parsing.parseListner;

public class MainActivity extends Activity implements parseListner {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
/**
 * How to call
 */
//	HashMap<String, String> Paramter;
//	PostDataAndGetData psd;
//
//	private void CallWsCalender(String business, String service, String emp,int month) {
//
//		psd = new PostDataAndGetData(
//				CalendarView.this,
//				null,
//				null,
//				"GET",
//				"http://184.164.156.56/projects//ws/Service/check_availability/?business_id="
//						+ business
//						+ "&service_id="
//						+ service
//						+ "&employee_id="
//						+ emp + "&month="+month, 0, 0, false, true);
//
//		psd.execute();
//
//	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private LinkedHashMap<String, Object> temp;
	private ArrayList<LinkedHashMap<String, Object>> jsonData;
	private String WebUrl, category_id, subcategory_id, county_id,
			localarea_id, business_id, service_id, booking_option, employee_id;
	ArrayList<Object> arrayList;
	
//
//	@SuppressWarnings("unchecked")
//	@Override
//	public void GetResult(Object jsonDataO, int responce) {
//		try {
//			arrayList = (ArrayList<Object>) jsonDataO;
//			ArrayList<LinkedHashMap<String, Object>> jsonDataTemp = (ArrayList<LinkedHashMap<String, Object>>) jsonDataO;
//			int size = arrayList.size();
//			if (size != 0) {
//				temp = (LinkedHashMap<String, Object>) arrayList.get(0);
//				if (temp.get("success").equals("1")) {
//					jsonData = jsonDataTemp;
//					switch (responce) {
//					case Business:
//						((TextView) findViewById(R.id.title))
//								.setText(getResources().getString(
//										R.string.str_business));
//						comonUti.findViewById();
//						comonUti.categorytype = "business";
//						business_adapter = new BusinessAdapterList(
//								BusinessListScreen.this, jsonData);
//						business_adapter.notifyDataSetInvalidated();
//						// mycategorylist.invalidate();
//						mycategorylist.setAdapter(business_adapter);
//						break;
//					case Service:
//						((TextView) findViewById(R.id.title))
//								.setText(getResources().getString(
//										R.string.str_service));
//						comonUti.findViewById();
//						comonUti.categorytype = "service";
//						service_adapter = new ServiceAdapterList(
//								BusinessListScreen.this, jsonData);
//						service_adapter.notifyDataSetInvalidated();
//						// mycategorylist.invalidate();
//						mycategorylist.setAdapter(service_adapter);
//						break;
//					case Employee:
//						((TextView) findViewById(R.id.title))
//								.setText(getResources().getString(
//										R.string.str_empolyee));
//						comonUti.findViewById();
//						comonUti.categorytype = "employee";
//						employee_adapter = new EmpolyeeAdapterList(
//								BusinessListScreen.this, jsonData);
//						service_adapter.notifyDataSetInvalidated();
//						// mycategorylist.invalidate();
//						mycategorylist.setAdapter(employee_adapter);
//						break;
//
//					default:
//						break;
//					}
//				} else {
//					comonUti.categorytype = tempcategorytype;
//					mycategorylist.setVisibility(View.GONE);
//					((TextView) findViewById(R.id.txt_msg))
//							.setVisibility(View.VISIBLE);
//					Setmsg();
//
//				}
//			} else {
//				comonUti.categorytype = tempcategorytype;
//				mycategorylist.setVisibility(View.GONE);
//				((TextView) findViewById(R.id.txt_msg))
//						.setVisibility(View.VISIBLE);
//				Setmsg();
//			}
//		} catch (Exception e) {
//			mycategorylist.setVisibility(View.GONE);
//			((TextView) findViewById(R.id.txt_msg)).setVisibility(View.VISIBLE);
//			Setmsg();
//			e.getStackTrace();
//		}
//
//	}
//
//	
	@Override
	public void GetResult(Object jsonDataO, int responce) {
		// TODO Auto-generated method stub
		
	}

}
