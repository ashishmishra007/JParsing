package com.Ashish.Parsing;

public interface parseListner {
	public void GetResult(Object jsonDataO, int responce);
}
